#include<stdio.h>
#include"freertos/FreeRTOS.h"
#include"freertos/task.h"

#include"st7735_driver.h"

void app_main(void)
{
    //spi_init();

    //st7735 init all
    st7735_init();

    uint16_t*data=(uint16_t*)malloc(128*128*sizeof(uint16_t));

    for(uint32_t i=0;i<128*128;++i)
    {
        data[i]=0x0000;
    }
    //st7735 flash color
    st7735_flash(0,0,160-1,80-1,data);
}
